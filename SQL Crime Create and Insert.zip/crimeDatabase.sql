CREATE TABLE Crimes(
	name varchar(255),
	lats decimal(15,12),
	longs decimal(15,12),
	address varchar(255),
	cDate Datetime, 
	type varchar(45)
);
